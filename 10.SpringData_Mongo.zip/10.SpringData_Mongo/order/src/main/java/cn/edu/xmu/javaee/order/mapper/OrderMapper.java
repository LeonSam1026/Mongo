package cn.edu.xmu.javaee.order.mapper;

import cn.edu.xmu.javaee.order.dao.bo.Order;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.util.Objects;
import java.util.Optional;


@Repository
public interface OrderMapper extends MongoRepository<Order, String>{

    Order findFirstByOrderSn(String orderSn);
}
